# 多Agent工作流：时序ECO Signoff — 痛点一

> 从海量时序数据中识别根因

## 场景

你正在处理大型设计的时序signoff问题。从Cadence工具 (PT/RC格式) 获得海量时序违例数据，有数百或数千个违例。挑战是识别具体违例根因并获得可执行的迭代策略。

## Agent团队

| Agent | 在此工作流中的角色 |
|-------|-------------------|
| 时序数据解析 | 解析PT/RC、SPEF、SDC格式为统一数据库 |
| 违例分析 | 分类违例并识别根因模式 |
| ECO策略生成 | 生成优先级排序的ECO策略 |
| Cadence工具接口 | 将策略翻译为Cadence命令 |
| Signoff质量门 | 验证signoff标准 |

## 工作流

### 步骤1 — 激活时序数据解析

```
激活 时序数据解析。

解析以下时序数据文件，项目 [芯片名称]:
- PT/RC时序数据: /project/timing/pt_rc_output/
- SPEF寄生参数文件: /project/timing/parasitics/
- SDC约束: /project/design/constraints/
- Cadence时序报告: /project/timing/reports/

数据格式: Cadence Innovus和Synopsys PrimeTime，PT/RC (Galois/ETM) 格式
工具链: Cadence (Innovus/PTEco) + Synopsys (PrimeTime)

输出要求:
1. 创建归一化为ps的统一时序数据库
2. 提取所有带完整路径信息的时序违例
3. 识别时钟域和CDC路径
4. 记录net电容和转换数据
5. 报告数据质量标志

完成后记住为 [芯片名称] 标记解析的时序数据库。
```

### 步骤2 — 激活违例分析

```
激活 违例分析。

项目: [芯片名称]
模式: 标准 (根因识别)

接收来自时序数据解析的解析时序数据库。

分析任务:

1. 违例分流
   - 按path_type (setup/hold)、clock_domain、severity分组
   - 按WNS识别Top 20最关键违例
   - 计算时钟域间违例分布

2. 模式识别
   查找这些常见根因模式:
   - 逻辑深度簇: 类似逻辑深度的违例暗示库或sizing问题
   - Net电容异常值: 电容>阈值的net表示布线问题
   - 时钟域模式: 显示违例的CDC路径表示交叉问题
   - Cell类型簇: 出现在多个违例中的相同cell类型暗示库问题

3. 根因归因
   对于每个主要违例簇:
   - 主要根因: 最主要的影响原因
   - 贡献因素: 放大问题的次要问题
   - 受影响NET/CELL: 需要关注的特定实例

4. 分类输出
   为每个违例分类:
   - root_cause_category: BUFFER_SIZING | CELL_SIZING | NET_ROUTING | CLOCK_TREE | LOGIC_DEPTH | CDC_ISSUE | LIBRARY_ISSUE | PHYSICAL
   - confidence: 0-100 (此分类的确定程度)
   - suggested_fix_category: 需要的ECO策略类型

输出格式:
- 完整违例分析报告
- 根因摘要表
- Top 10关键违例及具体根因
- 识别的模式簇

完成后记住为 [芯片名称] 标记违例分析。
```

### 步骤3 — 激活ECO策略生成

```
激活 ECO策略生成。

项目: [芯片名称]
模式: 标准

接收来自违例分析的违例分析。

对于识别的最关键违例，生成具体ECO策略:

1. 对于每个违例或违例簇:
   a. 列出导致问题的具体cell/net
   b. 生成2-3个候选修复策略
   c. 按: 影响 (恢复的slack量) vs 工作量 (1-5复杂度) 排序
   d. 包含用于实施的特定Cadence工具命令

2. 每个违例的策略格式:
   违例: [endpoint/path]
   根因: [识别的原因]
   置信度: [X]%

   建议修复:
   - 策略: [buffer_insert | cell_upsize | net_shield | clock_balance | logic_opt]
   - 具体操作: [详细实施步骤]
   - 预期改善: [ps改善估算]
   - 风险: [LOW/MEDIUM/HIGH]
   - Cadence命令:
     * [Innovus/PTEco的具体命令]

3. 迭代计划:
   按以下排序修复顺序:
   - 高影响 + 低工作量 = 优先做
   - 高影响 + 高工作量 = 第二做
   - 低影响 + 任何工作量 = 评估是否值得

输出格式:
- 完整ECO策略报告
- 优先级排序的策略列表
- 批量修复建议
- 预期总改善

完成后为 [芯片名称] 标记ECO策略，并准备好给Cadence工具接口。
```

### 步骤4 — 质量门检查 (继续前)

```
激活 Signoff质量门。

项目: [芯片名称]
上下文: 实施策略前的预ECO验证

接收当前时序数据 (ECO前)。

验证任务:
1. 验证当前WNS/TNS值作为基准
2. 检查所有corner已分析
3. 验证数据完整性
4. 设置用于比较的基准metrics

输出: 带基准metrics的预ECO验证报告。
```

### 步骤5 — 继续到实施

```
激活 Cadence工具接口。

项目: [芯片名称]

接收来自ECO策略生成的ECO策略。
接收来自Signoff质量门的基准验证。

实施任务:
1. 将每个策略翻译为具体的Innovus命令
2. 按优先级顺序执行策略
3. 每批次后运行增量时序
4. 每批次后验证DRC
5. 每个阶段保存检查点

对于每个策略:
- 提供完整命令序列
- 包含验证命令
- 包含回滚命令

输出: 实施报告，含执行的命令和结果。
```

### 步骤6 — 最终验证

```
激活 Signoff质量门。

项目: [芯片名称]
上下文: ECO后验证，确定是否达到signoff

接收:
- 预ECO基准metrics
- ECO后时序数据
- 实施报告

验证任务:
1. 比较前后的WNS/TNS
2. 验证所有主要标准: WNS >= 0 ps, TNS = 0 ps
3. 检查次要标准: margins, clock skew等
4. 给出GO/NO-GO/CONDITIONAL决定

输出: 带清晰GO/NO-GO决定的Signoff验证报告。

如果GO:
→ 时序signoff已达成，流水线完成

如果NO-GO:
→ 带着更新的数据返回步骤2或3，进行下次迭代
```

## 关键模式

1. **顺序交接**: 每个Agent的输出成为下一个Agent的输入
2. **质量门**: 预ECO和后ECO验证确保进度可衡量
3. **上下文传递**: 始终包含前一个Agent的输出 — Agent间不共享内存
4. **迭代循环**: 如果质量门失败，带着新上下文循环回分析

## 提示

- 在步骤间复制粘贴Agent输出 — 不要总结，使用完整输出
- 如果违例分析识别<80%已分类违例，请求更深入分析
- 如果ECO策略生成每个簇产出<2个策略，请求额外选项
- 如果Signoff质量门给出NO-GO，始终在迭代前捕获具体失败原因
