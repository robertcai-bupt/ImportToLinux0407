# Timing ECO Agent Team

Multi-Agent system for chip timing ECO signoff workflow in physical design.

## Team Structure

```
timing_eco_team/
├── agents/                          # Agent definitions
│   ├── orchestrator.md             # Workflow coordinator
│   ├── timing_data_parser.md        # EDA data ingestion
│   ├── violation_analyzer.md        # Violation analysis
│   ├── eco_strategy_generator.md    # ECO planning
│   ├── cadence_tool_integrator.md   # Tool execution
│   ├── signoff_quality_gate.md      # Quality validation
│   └── timing_comparator.md         # Version comparison
├── workflows/                       # Workflow definitions
│   ├── workflow-timing-eco-signoff.md   # Main ECO pipeline
│   ├── workflow-timing-comparison.md     # Version comparison
│   └── workflow-final-cleanup.md         # Residual violation cleanup
├── team.yaml                        # Team configuration
└── README.md                        # This file
```

## Agents

| Agent | Role | Responsibility |
|-------|------|----------------|
| **TimingDataParser** | Data Ingestion | Parse PT/RC, SPEF, SDC, TWR timing files |
| **ViolationAnalyzer** | Violation Analysis | Classify violations, identify root causes |
| **ECOStrategyGenerator** | ECO Planning | Generate prioritized fix strategies |
| **CadenceToolIntegrator** | Tool Execution | Translate strategies to Cadence commands |
| **SignoffQualityGate** | Quality Validation | Validate signoff criteria, issue GO/NO-GO |
| **TimingComparator** | Version Comparison | Compare versions, track changes |
| **Orchestrator** | Workflow Coordinator | Orchestrate agent execution flow |

## Workflows

### 1. Timing ECO Signoff (Main Pipeline)
Sequential pipeline for root cause identification from massive timing data.

**Execution order:**
```
TimingDataParser → ViolationAnalyzer → ECOStrategyGenerator → CadenceToolIntegrator → SignoffQualityGate
```

### 2. Timing Comparison
Version/stage comparison for trend and root cause analysis.

**Execution order:**
```
TimingDataParser (A) ─┬─→ TimingComparator → ViolationAnalyzer (if issues) → ECOStrategyGenerator
TimingDataParser (B) ─┘
```

### 3. Final Cleanup
Surgical precision analysis for residual violations (<50).

**Execution order:**
```
ViolationAnalyzer (Deep Dive) → ECOStrategyGenerator (Final Cleanup) → CadenceToolIntegrator → SignoffQualityGate
```

## Usage

### Starting a Timing ECO Signoff Workflow

```markdown
Use the following agents in sequence:

1. Activate TimingDataParser with:
   - Project: [CHIP_NAME]
   - Files: PT/RC, SPEF, SDC, TWR from /project/timing/
   - Format: Cadence Innovus with PT/RC

2. Activate ViolationAnalyzer with:
   - Mode: STANDARD
   - Input: Parsed timing database from TimingDataParser
   - Goal: >80% classified with confidence >70%

3. Activate ECOStrategyGenerator with:
   - Mode: STANDARD
   - Input: Violation analysis from ViolationAnalyzer
   - Goal: 2+ strategies per violation cluster

4. Activate CadenceToolIntegrator with:
   - Input: ECO strategies from ECOStrategyGenerator
   - Execute in priority order

5. Activate SignoffQualityGate with:
   - Input: Post-ECO timing data
   - Decision: GO/NO-GO/CONDITIONAL
```

### Starting a Timing Comparison Workflow

```markdown
Use the following agents:

1. Activate TimingDataParser (parallel, two instances):
   - Instance A: Parse Version A timing data
   - Instance B: Parse Version B timing data

2. Activate TimingComparator with:
   - Version A: Baseline timing database
   - Version B: Comparison timing database
   - Goal: Classify FIXED/NEW/DEGRADED/IMPROVED

3. If issues found:
   - Activate ViolationAnalyzer (DEEP_DIVE for new/degraded)
   - Activate ECOStrategyGenerator (COMPARISON_FOLLOWUP)
```

### Starting a Final Cleanup Workflow

```markdown
Use the following agents:

1. Activate ViolationAnalyzer with:
   - Mode: DEEP_DIVE
   - Context: [N] ECO iterations completed, [X] violations remain
   - Goal: Per-violation surgical analysis

2. Activate ECOStrategyGenerator with:
   - Mode: FINAL_CLEANUP
   - Input: Deep dive violation analysis
   - Goal: Precision fixes, batch optimization

3. Activate CadenceToolIntegrator with:
   - Mode: FINAL_CLEANUP
   - Execute targeted fixes by phase

4. Activate SignoffQualityGate with:
   - Context: Final validation
   - Decision: GO/NO-GO/CONDITIONAL
```

## Communication Protocol

- Agents communicate via structured messages with context preservation
- Each agent's output becomes the next agent's input
- Quality gates between phases ensure progress validation
- NO-GO decisions trigger iteration loops

## Iteration Loop

```
                    ┌─────────────────┐
                    │  SignoffQuality │
                    │      Gate       │
                    └────────┬────────┘
                             │
              ┌──────────────┼──────────────┐
              │              │              │
              ▼ NO-GO        ▼ GO           ▼ CONDITIONAL
    ┌─────────────────┐   ┌───────┐   ┌─────────────┐
    │ Return to       │   │ Pipeline│   │ Proceed with│
    │ Phase 2 or 3     │   │Complete│   │  monitoring │
    └─────────────────┘   └───────┘   └─────────────┘
              │                                  │
              └──────────────────────────────────┘
                         (Iteration count++)
```

## Quality Gate Thresholds

| Phase | Gate Criterion |
|-------|----------------|
| Data Ingestion | Data complete, quality flags documented |
| Violation Analysis | >80% classified, confidence >70% |
| Strategy Generation | 2+ strategies per violation cluster |
| ECO Implementation | No execution errors, DRC clean |
| Quality Validation | WNS >= 0 ps, TNS = 0 ps |

## Max Iterations

- Per phase: 3 retries
- Total pipeline: 10 iterations
- Exceeding max: Escalate to manual intervention
