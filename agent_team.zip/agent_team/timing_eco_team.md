# Timing ECO Agent Team

> Multi-Agent system for timing ECO signoff workflow in chip physical design

## Team Overview

| Agent | Role | Responsibility |
|-------|------|----------------|
| TimingDataParser | EDA Data Ingestion | Parse PT/RC, SPEF, SDC, TWR timing files |
| ViolationAnalyzer | Violation Analysis | Classify violations, identify root causes |
| ECOStrategyGenerator | ECO Planning | Generate prioritized fix strategies |
| CadenceToolIntegrator | Tool Execution | Translate strategies to Cadence commands |
| SignoffQualityGate | Quality Validation | Validate signoff criteria, issue GO/NO-GO |
| TimingComparator | Version Comparison | Compare versions, track changes |
| Orchestrator | Workflow Coordinator | Orchestrate agent execution flow |

## Workflows

### Workflow 1: Timing ECO Signoff (Pain Point 1)
Sequential pipeline for root cause identification from massive timing data.

```
TimingDataParser → ViolationAnalyzer → ECOStrategyGenerator → CadenceToolIntegrator → SignoffQualityGate
```

### Workflow 2: Timing Comparison (Pain Point 2)
Version/stage comparison for trend and root cause analysis.

```
TimingDataParser (A) ─┬─→ TimingComparator → ViolationAnalyzer (if issues) → ECOStrategyGenerator
TimingDataParser (B) ─┘
```

### Workflow 3: Final Cleanup (Pain Point 3)
Surgical precision analysis for residual violations (<50).

```
ViolationAnalyzer (Deep Dive) → ECOStrategyGenerator (Final Cleanup) → CadenceToolIntegrator → SignoffQualityGate
```

## Communication Protocol

- Agents communicate via structured messages with context preservation
- Each agent's output becomes the next agent's input (sequential handoff)
- Quality gates between phases ensure progress validation
- NO-GO decisions trigger iteration loops back to appropriate phase
