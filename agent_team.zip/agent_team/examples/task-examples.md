# Task Examples for Timing ECO Agent Team

## Example 1: Full Timing ECO Signoff Pipeline

```
Project: CHIP_V1
Stage: PostRoute Signoff
Iteration: 1
Input Files:
  - PT/RC: /project/chip_v1/timing/pt_rc_output/
  - SPEF: /project/chip_v1/timing/parasitics/
  - SDC: /project/chip_v1/design/constraints/
  - TWR: /project/chip_v1/timing/reports/
Toolchain: Cadence (Innovus/PTEco) + Synopsys (PrimeTime)
```

### Step 1: Timing Data Parser

```
Activate TimingDataParser.

Parse the following timing data files for project CHIP_V1:
- PT/RC timing data from: /project/chip_v1/timing/pt_rc_output/
- SPEF parasitic files from: /project/chip_v1/timing/parasitics/
- SDC constraints from: /project/chip_v1/design/constraints/
- Cadence timing reports from: /project/chip_v1/timing/reports/

Data Format: Cadence Innovus with PT/RC (Galois/ETM) format
Toolchain: Cadence (Innovus/PTEco) + Synopsys (PrimeTime)

Output Requirements:
1. Create a unified timing database with normalized units (ps)
2. Extract all timing violations with full path information
3. Identify clock domains and CDC paths
4. Document net capacitance and transition data
5. Report data quality flags

Remember the parsed timing database tagged for CHIP_V1 when done.
```

### Step 2: Violation Analyzer

```
Activate ViolationAnalyzer.

Project: CHIP_V1
Mode: STANDARD (root cause identification)

Recall the parsed timing database from the Timing Data Parser.

Analysis Tasks:

1. VIOLATION TRIAGE
   - Group violations by: path_type (setup/hold), clock_domain, severity
   - Identify top 20 most critical violations by WNS
   - Calculate violation distribution across clock domains

2. PATTERN RECOGNITION
   Look for these common root cause patterns:
   - Logical depth clusters: violations grouped by similar logic depth
   - Net capacitance outliers: nets with capacitance > threshold
   - Clock domain patterns: CDC paths showing violations
   - Cell-type clusters: same cell type appearing in many violations

3. ROOT CAUSE ATTRIBUTION
   For each major violation cluster, identify:
   - PRIMARY ROOT CAUSE: The single most impactful cause
   - CONTRIBUTING FACTORS: Secondary issues amplifying the problem
   - AFFECTED NETS/CELLS: Specific instances requiring attention

4. CLASSIFICATION OUTPUT
   Classify each violation with:
   - root_cause_category: BUFFER_SIZING | CELL_SIZING | NET_ROUTING | CLOCK_TREE | LOGIC_DEPTH | CDC_ISSUE | LIBRARY_ISSUE | PHYSICAL
   - confidence: 0-100 (how certain is this classification)
   - suggested_fix_category: The ECO strategy type needed

Output Format:
- Complete violation analysis report
- Root cause summary table
- Top 10 critical violations with specific root causes
- Pattern clusters identified

Remember the violation analysis tagged for CHIP_V1 when done.
```

### Step 3: ECO Strategy Generator

```
Activate ECO Strategy Generator.

Project: CHIP_V1
Mode: STANDARD

Recall the violation analysis from the Violation Analyzer.

For the top critical violations identified, generate specific ECO strategies:

1. For each violation or violation cluster:
   a. List the specific cells/nets causing the issue
   b. Generate 2-3 candidate fix strategies
   c. Rank by: IMPACT (how much slack recovered) vs EFFORT (1-5 complexity)
   d. Include specific Cadence tool commands for implementation

2. STRATEGY FORMAT per violation:
   VIOLATION: [endpoint/path]
   ROOT_CAUSE: [identified cause]
   CONFIDENCE: [X]%

   RECOMMENDED_FIX:
   - Strategy: [buffer_insert | cell_upsize | net_shield | clock_balance | logic_opt]
   - Specific Action: [detailed implementation step]
   - Expected Improvement: [ps improvement estimate]
   - Risk: [regression potential: LOW/MEDIUM/HIGH]
   - Cadence Commands:
     * [specific command for Innovus/PTEco]

3. ITERATION PLAN:
   Prioritize the order of fixes based on:
   - High impact + Low effort = Do first
   - High impact + High effort = Do second
   - Low impact + Any effort = Evaluate if worthwhile

Output Format:
- Complete ECO strategy report
- Priority-ordered strategy list
- Batch recommendations for grouped fixes
- Expected total improvement

Remember the ECO strategies tagged for CHIP_V1 and for the Cadence Tool Integrator when done.
```

### Step 4: Cadence Tool Integrator

```
Activate Cadence Tool Integrator.

Project: CHIP_V1

Recall the ECO strategies from the ECO Strategy Generator.
Recall the baseline validation from the Signoff Quality Gate.

Implementation Tasks:
1. Translate each strategy to specific Innovus commands
2. Execute strategies in priority order
3. Run incremental timing after each batch
4. Validate DRC after each batch
5. Save checkpoints at each stage

For each strategy:
- Provide complete command sequence
- Include verification commands
- Include rollback commands

Output: Implementation report with commands executed and results.
```

### Step 5: Signoff Quality Gate

```
Activate Signoff Quality Gate.

Project: CHIP_V1
Context: Post-ECO validation to determine if signoff is achieved

Recall:
- Pre-ECO baseline metrics
- Post-ECO timing data
- Implementation report

Validation Tasks:
1. Compare WNS/TNS before vs after
2. Verify all primary criteria: WNS >= 0 ps, TNS = 0 ps
3. Check secondary criteria: margins, clock skew, etc.
4. Issue GO/NO-GO/CONDITIONAL decision

Output: Signoff validation report with clear GO/NO-GO/CONDITIONAL decision.

IF GO:
→ Timing signoff achieved, pipeline complete

IF NO-GO:
→ Return to Step 2 or 3 with updated data for next iteration
```

---

## Example 2: Version Comparison

```
Compare timing data between ECO iteration 2 and ECO iteration 3 for project CHIP_V1.

Version A (Baseline):
- Version ID: v2_iteration
- Date: 2026-03-20
- Violations: 127
- WNS: -150 ps

Version B (Comparison):
- Version ID: v3_iteration
- Date: 2026-03-25
- Violations: 45
- WNS: -45 ps
```

### Step 1-2: Parallel Data Parsing

```
Activate TimingDataParser.

Parse timing data for BASELINE VERSION:
- Version ID: v2_iteration
- Date/Path: 2026-03-20
- Stage: PostRoute

Files:
- PT/RC timing data from: /project/chip_v1/timing/v2/
- SPEF parasitic files from: /project/chip_v1/parasitics/v2/
- SDC constraints from: /project/chip_v1/design/constraints/
- Timing reports from: /project/chip_v1/timing/reports/v2/

Remember Version A timing database tagged for v2_iteration when done.
```

```
Activate TimingDataParser.

Parse timing data for COMPARISON VERSION:
- Version ID: v3_iteration
- Date/Path: 2026-03-25
- Stage: PostRoute

Files:
- PT/RC timing data from: /project/chip_v1/timing/v3/
- SPEF parasitic files from: /project/chip_v1/parasitics/v3/
- SDC constraints from: /project/chip_v1/design/constraints/
- Timing reports from: /project/chip_v1/timing/reports/v3/

Remember Version B timing database tagged for v3_iteration when done.
```

### Step 3: Timing Comparator

```
Activate Timing Comparator.

Project: CHIP_V1
Comparison Type: VERSION_ITERATION

Recall timing databases:
- Version A (Baseline): v2_iteration
- Version B (Comparison): v3_iteration

COMPARISON TASKS:

1. METRIC DELTA ANALYSIS
   Calculate for each metric:
   - violation_count_delta = count_B - count_A
   - wns_delta = wns_B - wns_A (positive = improvement)
   - tns_delta = tns_B - tns_A (positive = improvement)
   - critical_path_change = [path migration details]

2. VIOLATION CLASSIFICATION
   Categorize all violations:
   - FIXED: Violations in A that are not in B
   - NEW: Violations in B that were not in A
   - DEGRADED: Violations in both but worse in B
   - IMPROVED: Violations in both but better in B

3. CRITICAL PATH MIGRATION
   - Did the critical path change locations?
   - What nets/cells are newly critical?
   - What nets/cells improved?

4. ROOT CAUSE CHANGE ATTRIBUTION
   - What changed in the design that caused this?
   - Correlation with known ECO actions taken
   - Any unexpected changes requiring investigation?

5. EXECUTIVE SUMMARY
   Generate a PASS/FAIL/CONDITIONAL assessment

Output Format:
1. Summary table (metric | Version A | Version B | Delta)
2. Detailed change lists (fixed, new, degraded)
3. Root cause analysis for major changes
4. Critical path migration analysis
5. Recommended actions for next iteration

Remember the comparison report tagged for CHIP_V1 when done.
```

---

## Example 3: Final Cleanup

```
Context for Final Cleanup:

Iteration Count: 4
Remaining Violations: 12
- Setup violations: 8
- Hold violations: 4
- Worst Slack: -35 ps
- Total Negative Slack: -180 ps

Historical Progression:
| Iteration | Start | End | WNS Start | WNS End |
|-----------|-------|-----|-----------|---------|
| 1 | 127 | 82 | -150 ps | -95 ps |
| 2 | 82 | 45 | -95 ps | -45 ps |
| 3 | 45 | 20 | -45 ps | -30 ps |
| 4 | 20 | 12 | -30 ps | -35 ps |

Current Status: Standard ECO has been applied. 12 hard cases remain.
```

### Step 1: Violation Analyzer (Deep Dive)

```
Activate Violation Analyzer.

Project: CHIP_V1
Mode: DEEP_DIVE (remaining violations cleanup)

Context: After 4 ECO iterations, 12 violations remain. Standard analysis has been applied.
Now we need surgical precision for these remaining hard cases.

Remaining Violations: [LIST FROM PREVIOUS ANALYSIS]

DEEP DIVE ANALYSIS TASKS:

1. PER-VIOLATION PATH EXTRACTION
   For each remaining violation:

   VIOLATION: [violation_id]
   ENDPOINT: [full path endpoint]
   CURRENT SLACK: [X] ps

   Full Path Analysis:
   - Launch FF: [cell name] at ({x, y})
   - Capture FF: [cell name] at ({x, y})
   - Path depth: [N] logic levels
   - Clock skew: [X] ps
   - Clock domain: [domain_name]

   Cell-by-Cell Breakdown:
   | Cell Instance | Cell Type | Delay (ps) | Input Trans (ps) | Output Load (ff) |

   Net Analysis:
   | Net Name | Fanout | Total Cap (ff) | Routing Layer | Shielding |

2. MULTI-VIOLATION CORRELATION
   IMPORTANT: Often 1 fix resolves multiple violations!

3. LIBRARY CORNER ANALYSIS
   - Compare actual delay vs library model at this corner
   - Check if cell is operating near library limits

4. PHYSICAL PROXIMITY ANALYSIS
   - Neighboring cell density (congestion)
   - Distance to driving/receiving cells
   - Layer assignment for critical nets

OUTPUT FORMAT:

For EACH remaining violation:

## [Violation ID]: [Endpoint]

### ROOT CAUSE: [Specific, actionable root cause]
- Not "LOGIC_DEPTH" but "Cell UCB4 in path has delay 850ps vs library model 720ps"

### CORRELATED VIOLATIONS: [List if any other violations caused by same issue]

### TAILORED FIX: [Specific strategy for this exact case]
- Exact cell change: [cell_name], [current_type] → [recommended_type]
- OR exact buffer insertion: [net_name], [buffer_type], [location]
- OR exact routing change: [net_name], [layer_change], [shielding_type]

### CONFIDENCE: [X]%

### CADENCE COMMANDS:
Innovus:
> [precise innovus command for this fix]

PrimeTime:
> [verification command after fix]

### FLAGGED FOR MANUAL REVIEW: [YES/NO]

Remember the deep dive analysis tagged for CHIP_V1 when done.
```

### Step 2: ECO Strategy Generator (Final Cleanup)

```
Activate ECO Strategy Generator.

Project: CHIP_V1
Mode: FINAL_CLEANUP

Recall the deep dive violation analysis from the Violation Analyzer.

These are the final 12 violations blocking signoff. Standard ECO has been applied.
We need precision fixes for these specific cases.

FINAL CLEANUP STRATEGY TASKS:

1. SURGICAL FIX GENERATION
   For each remaining violation:

   VIOLATION: [violation_id]
   ROOT_CAUSE: [specific cause from deep dive]

   TAILORED_FIX:
   - Exact cell change: [cell_name], [current_type] → [recommended_type]
   - OR exact buffer insertion location: [net_name], [recommended_buffer_type]
   - OR exact routing change: [net_name], [layer_change], [shielding]
   - Expected slack improvement: [X] ps
   - Risk of regression: [LOW/MEDIUM/HIGH]

2. BATCH OPTIMIZATION
   If multiple violations share a cause:
   - Can one cell change fix multiple violations?
   - What's the optimal order of fixes to avoid regression?
   - Group fixes into minimal ECO operations

3. MANUAL INTERVENTION FLAGGING
   For violations where automated fix is risky/low-confidence:
   ## MANUAL ECO REQUIRED: [Violation ID]
   - Why automated fix is risky: [explanation]
   - Recommended approach: [detailed steps]
   - Expert level required: [Junior/Senior/Expert]

4. SIGN-OFF RISK ASSESSMENT
   | Violation | Fix Success Prob | True Resolution | Corner Risk |
   |-----------|-----------------|-----------------|--------------|
   | V001 | 92% | Yes | LOW |

OUTPUT FORMAT:
- Final cleanup strategy document
- Priority-ordered fix list
- Batch recommendations
- Manual intervention checklist
- Signoff readiness assessment

Remember the final cleanup strategy tagged for CHIP_V1 when done.
```

### Step 3: Cadence Tool Integrator (Final Cleanup)

```
Activate Cadence Tool Integrator.

Project: CHIP_V1
Mode: FINAL_CLEANUP

Recall the final cleanup strategies from ECO Strategy Generator.

Implementation Priority:

PHASE 1: Safe Automated Fixes (High Confidence)
1. Batch A: [list fixes]
2. Verify after each batch

PHASE 2: Medium Confidence Fixes
1. [list fixes]
2. Verify after each fix

PHASE 3: Manual ECO (if flagged)
1. [list violations requiring manual intervention]
2. Provide detailed context for manual ECO

For each automated fix:
- Execute precise Cadence command
- Verify slack improvement
- Check for regressions
- Save checkpoint

Output: Implementation report with results for each fix.
```

### Step 4: Signoff Quality Gate (Final)

```
Activate Signoff Quality Gate.

Project: CHIP_V1
Context: Final validation after all remaining violation fixes

Recall:
- Previous iteration metrics
- New timing data after final cleanup fixes
- Implementation results

FINAL VALIDATION TASKS:

1. PRIMARY CRITERIA
   - WNS (Setup) >= 0 ps: [ACTUAL] ps → PASS/FAIL
   - WNS (Hold) >= 0 ps: [ACTUAL] ps → PASS/FAIL
   - TNS (Setup) = 0 ps: [ACTUAL] ps → PASS/FAIL
   - TNS (Hold) = 0 ps: [ACTUAL] ps → PASS/FAIL

2. MARGIN ASSESSMENT
   - Setup margin > 10 ps: [ACTUAL] ps → PASS/FAIL
   - Hold margin > 5 ps: [ACTUAL] ps → PASS/FAIL
   - Clock skew within limits: [ACTUAL] ps → PASS/FAIL

3. QUALITY ASSESSMENT
   - Overall robustness: [HIGH/MEDIUM/LOW]
   - Risk factors identified: [list]
   - Remaining concerns: [list]

FINAL DECISION:

[ ] ✅ GO — All criteria met with adequate margin. Design ready for signoff.

[ ] ❌ NO-GO — Criteria not met. Return to analysis.

[ ] ⚠️ CONDITIONAL — Criteria met with conditions.
  Conditions:
  1. [condition 1]
  2. [condition 2]

Output: Final signoff validation report with clear GO/NO-GO/CONDITIONAL decision.
```
