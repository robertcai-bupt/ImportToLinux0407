# Workflow: Timing Comparison

> Pain Point 2: Version/Stage Comparison for Trend and Root Cause Analysis

## Overview

Compare timing data between two versions (before/after ECO iteration) or between stages (CTS vs Route vs PostRoute).

## Workflow Graph

```
┌─────────────────┐     ┌─────────────────┐
│TimingDataParser │     │TimingDataParser │
│  (Version A)    │     │  (Version B)    │
└────────┬────────┘     └────────┬────────┘
         │                       │
         └───────────┬───────────┘
                     ▼
         ┌─────────────────┐
         │TimingComparator │
         └────────┬────────┘
                  │
         ┌────────┴────────┐
         ▼                 ▼
┌─────────────────┐ ┌─────────────────┐
│ViolationAnalyzer│ │  Orchestrator   │
│(if issues found)│ │  (if no issues) │
└────────┬────────┘ └─────────────────┘
         │
         ▼
┌─────────────────┐
│ECOStrategyGen   │
│(if fixes needed)│
└─────────────────┘
```

## Agents Involved

| Step | Agent | Role |
|------|-------|------|
| 1a | TimingDataParser | Parse Version A timing data |
| 1b | TimingDataParser | Parse Version B timing data |
| 2 | TimingComparator | Compare versions, calculate deltas |
| 3 | ViolationAnalyzer | Analyze new/degraded violations (conditional) |
| 4 | ECOStrategyGenerator | Generate fix strategies (conditional) |

## Step 1a: Timing Data Parser (Version A - Baseline)

**Version ID:** [VERSION_A_ID]
**Date/Path:** [PATH_OR_DATE]
**Stage:** [CTS | Route | PostRoute | Signoff]

**Files to parse:**
- PT/RC timing data from: [PATH_TO_VERSION_A_TIMING]
- SPEF parasitic files from: [PATH_TO_VERSION_A_SPEF]
- SDC constraints from: [PATH_TO_VERSION_A_SDC]
- Timing reports from: [PATH_TO_VERSION_A_REPORTS]

**Output Requirements:**
1. Unified timing database for Version A
2. All violations with full path information
3. Clock domain analysis
4. Data quality flags

## Step 1b: Timing Data Parser (Version B - Comparison)

**Version ID:** [VERSION_B_ID]
**Date/Path:** [PATH_OR_DATE]
**Stage:** [CTS | Route | PostRoute | Signoff]

**Files to parse:**
- PT/RC timing data from: [PATH_TO_VERSION_B_TIMING]
- SPEF parasitic files from: [PATH_TO_VERSION_B_SPEF]
- SDC constraints from: [PATH_TO_VERSION_B_SDC]
- Timing reports from: [PATH_TO_VERSION_B_REPORTS]

**Output Requirements:**
1. Unified timing database for Version B
2. All violations with full path information
3. Clock domain analysis
4. Data quality flags

## Step 2: Timing Comparator

**Comparison Type:** [VERSION_ITERATION | STAGE_COMPARISON | HISTORICAL_TRACKING]

**COMPARISON TASKS:**

### 1. METRIC DELTA ANALYSIS
Calculate for each metric:
- violation_count_delta = count_B - count_A
- wns_delta = wns_B - wns_A (positive = improvement)
- tns_delta = tns_B - tns_A (positive = improvement)
- critical_path_change = [path migration details]

### 2. VIOLATION CLASSIFICATION

**FIXED:** Violations in A that are not in B
- List top 10 fixed violations with their original slack

**NEW:** Violations in B that were not in A
- List all new violations with their current slack

**DEGRADED:** Violations in both but worse in B
- List violations where slack_B < slack_A

**IMPROVED:** Violations in both but better in B
- List violations where slack_B > slack_A

### 3. CRITICAL PATH MIGRATION
- Did the critical path change locations?
- What nets/cells are newly critical?
- What nets/cells improved?

### 4. ROOT CAUSE CHANGE ATTRIBUTION
- What changed in the design that caused this?
- Correlation with known ECO actions taken
- Any unexpected changes requiring investigation?

### 5. EXECUTIVE SUMMARY
Generate a PASS/FAIL/CONDITIONAL assessment:
- PASS: All metrics improved, no new critical violations
- FAIL: Significant degradation in key metrics
- CONDITIONAL: Mixed results requiring human review

**Output Format:**
1. Summary table (metric | Version A | Version B | Delta)
2. Detailed change lists (fixed, new, degraded)
3. Root cause analysis for major changes
4. Critical path migration analysis
5. Recommended actions for next iteration

## Step 3: Violation Analyzer (Conditional - if issues found)

**Context:** Timing comparison identified issues requiring analysis:
- [N] NEW violations introduced
- [N] DEGRADED violations

**Analysis Tasks:**

For NEW violations:
1. Extract full timing path for each new violation
2. Identify what changed in the design that caused new violations
3. Classify root cause category
4. Determine if fixable with standard ECO

For DEGRADED violations:
1. Compare path details between versions
2. Identify what specific change caused degradation
3. Classify root cause
4. Determine if recoverable

**Output:**
- Analysis of each new violation
- Analysis of each degraded violation
- Root cause summary
- Recommended fixes (if applicable)

## Step 4: ECO Strategy Generator (Conditional - if fixes needed)

**Context:** New/degraded violations identified in comparison analysis.

**For each new/degraded violation:**

```markdown
VIOLATION: [endpoint/path]
VERSION A SLACK: [X] ps (if existed)
VERSION B SLACK: [Y] ps
CHANGE: [Z] ps (degradation)

ROOT CAUSE: [identified cause]

RECOMMENDED FIX:
- Strategy: [buffer_insert | cell_upsize | net_shield | clock_balance | logic_opt]
- Specific Action: [detailed step]
- Expected Improvement: [X] ps
- Risk: [LOW/MEDIUM/HIGH]

CADENCE COMMANDS:
> [specific commands]
```

**Output:**
- Complete strategy list for new/degraded violations
- Priority order
- Batch recommendations
- Expected total improvement

## Step 5: Final Comparison Report

**Compile final comparison report including:**

### 1. EXECUTIVE SUMMARY
- Overall assessment: PASS/FAIL/CONDITIONAL
- Key metrics summary
- Recommendation

### 2. METRICS COMPARISON
| Metric | Version A | Version B | Delta | % Change |
|--------|----------|----------|-------|----------|
| WNS (ps) | [X] | [Y] | [Z] | [%] |
| TNS (ps) | [X] | [Y] | [Z] | [%] |
| Violations | [N] | [N] | [N] | [%] |

### 3. CHANGE CLASSIFICATION
- Fixed: [N] violations
- New: [N] violations
- Degraded: [N] violations
- Improved: [N] violations

### 4. ECO EFFECTIVENESS
- Correlation with known ECO actions: [X]%
- Unexpected changes: [N]
- Regression rate: [X]%

### 5. NEXT STEPS
- Continue iteration if violations remain
- Specific recommendations
- Predicted convergence

## Key Patterns

1. **Parallel parsing**: Both versions are parsed simultaneously for efficiency
2. **Structured comparison**: Clear classification of FIXED/NEW/DEGRADED/IMPROVED
3. **Root cause tracking**: Every change is attributed to a cause
4. **ECO correlation**: Changes are correlated with known ECO actions

## Comparison Report Template

```markdown
# Timing Comparison Report

## Version Information
| | Version A (Baseline) | Version B (Comparison) |
| Version ID | [ID] | [ID] |
| Date | [date] | [date] |
| Stage | [stage] | [stage] |

## Metric Summary
| Metric | Version A | Version B | Delta | Assessment |
|--------|-----------|----------|-------|------------|
| WNS (Setup) | -150 ps | -45 ps | +105 ps | ✅ Improved |
| WNS (Hold) | -80 ps | -25 ps | +55 ps | ✅ Improved |
| TNS (Setup) | -4500 ps | -890 ps | +3610 ps | ✅ Improved |
| Total Violations | 127 | 45 | -82 | ✅ Improved |
| Critical Paths | 20 | 20 | - | ⚠️ Migrated |

## Change Classification
- **Fixed Violations**: 82 (65%)
- **New Violations**: 0 (0%)
- **Degraded Violations**: 3 (2%)
- **Improved Violations**: 42 (33%)

## Assessment: ✅ PASS (Significant Improvement)
```
