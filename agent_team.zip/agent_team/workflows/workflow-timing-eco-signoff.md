# Workflow: Timing ECO Signoff

> Pain Point 1: Root Cause Identification from Massive Timing Data

## Overview

Full sequential pipeline for timing signoff from raw timing data to GO/NO-GO decision.

## Workflow Graph

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│ TimingDataParser│ ──▶ │ViolationAnalyzer│ ──▶ │ECOStrategyGen   │ ──▶ │CadenceToolInteg │ ──▶ │SignoffQualityGate│
└─────────────────┘     └─────────────────┘     └─────────────────┘     └─────────────────┘     └─────────────────┘
                                                                                                        │
                                                                                                        ▼
                                                                                                 ┌─────────────────┐
                                                                                                 │   Orchestrator   │
                                                                                                 │(Iteration Loop) │
                                                                                                 └─────────────────┘
```

## Agents Involved

| Step | Agent | Role |
|------|-------|------|
| 1 | TimingDataParser | Parse PT/RC, SPEF, SDC, TWR files |
| 2 | ViolationAnalyzer | Classify violations, identify root causes |
| 3 | ECOStrategyGenerator | Generate prioritized ECO strategies |
| 4 | CadenceToolIntegrator | Execute Cadence commands |
| 5 | SignoffQualityGate | Validate signoff criteria |
| - | Orchestrator | Coordinate flow, manage iterations |

## Step 1: Timing Data Parser

**Input:**
- PT/RC timing data from: /project/timing/pt_rc_output/
- SPEF parasitic files from: /project/timing/parasitics/
- SDC constraints from: /project/design/constraints/
- Cadence timing reports from: /project/timing/reports/

**Format:** Cadence Innovus with PT/RC (Galois/ETM) format

**Output Requirements:**
1. Create a unified timing database with normalized units (ps)
2. Extract all timing violations with full path information
3. Identify clock domains and CDC paths
4. Document net capacitance and transition data
5. Report data quality flags

**Context to pass:**
```
[CHIP_NAME] timing database created with:
- [N] violations identified
- [N] clock domains
- Data quality flags: [flags]
```

## Step 2: Violation Analyzer

**Input:** Unified timing database from TimingDataParser

**Mode:** STANDARD (root cause identification)

**Analysis Tasks:**

1. **VIOLATION TRIAGE**
   - Group violations by: path_type (setup/hold), clock_domain, severity
   - Identify top 20 most critical violations by WNS
   - Calculate violation distribution across clock domains

2. **PATTERN RECOGNITION**
   - Logical depth clusters
   - Net capacitance outliers
   - Clock domain patterns
   - Cell-type clusters

3. **ROOT CAUSE ATTRIBUTION**
   - PRIMARY ROOT CAUSE per violation cluster
   - CONTRIBUTING FACTORS
   - AFFECTED NETS/CELLS

4. **CLASSIFICATION OUTPUT**
   - root_cause_category: BUFFER_SIZING | CELL_SIZING | NET_ROUTING | CLOCK_TREE | LOGIC_DEPTH | CDC_ISSUE | LIBRARY_ISSUE | PHYSICAL
   - confidence: 0-100
   - suggested_fix_category

**Output:**
- Complete violation analysis report
- Root cause summary table
- Top 10 critical violations with specific root causes
- Pattern clusters identified

## Step 3: ECO Strategy Generator

**Input:** Violation analysis from ViolationAnalyzer

**For each violation or violation cluster:**
1. List the specific cells/nets causing the issue
2. Generate 2-3 candidate fix strategies
3. Rank by: IMPACT (slack recovered) vs EFFORT (1-5 complexity)
4. Include specific Cadence tool commands

**STRATEGY FORMAT:**
```markdown
VIOLATION: [endpoint/path]
ROOT_CAUSE: [identified cause]
CONFIDENCE: [X]%

RECOMMENDED_FIX:
- Strategy: [buffer_insert | cell_upsize | net_shield | clock_balance | logic_opt]
- Specific Action: [detailed implementation step]
- Expected Improvement: [ps improvement estimate]
- Risk: [regression potential: LOW/MEDIUM/HIGH]
- Cadence Commands:
  * [specific command for Innovus/PTEco]
```

**ITERATION PLAN:**
- High impact + Low effort = Do first
- High impact + High effort = Do second
- Low impact + Any effort = Evaluate if worthwhile

**Output:**
- Complete ECO strategy report
- Priority-ordered strategy list
- Batch recommendations for grouped fixes
- Expected total improvement

## Step 4: Cadence Tool Integrator

**Input:**
- ECO strategies from ECOStrategyGenerator
- Baseline validation from SignoffQualityGate

**Implementation Tasks:**
1. Translate each strategy to specific Innovus commands
2. Execute strategies in priority order
3. Run incremental timing after each batch
4. Validate DRC after each batch
5. Save checkpoints at each stage

**For each strategy:**
- Provide complete command sequence
- Include verification commands
- Include rollback commands

**Output:**
- Implementation report with commands executed and results

## Step 5: Signoff Quality Gate (Quality Gate Check)

**Context:** Pre-ECO validation before implementing strategies

**Validation Tasks:**
1. Verify current WNS/TNS values as baseline
2. Check all corners are analyzed
3. Validate data completeness
4. Set baseline metrics for comparison

**Output:** Pre-ECO validation report with baseline metrics.

## Step 6: Post-ECO Validation

**Input:**
- Pre-ECO baseline metrics
- Post-ECO timing data
- Implementation report

**Validation Tasks:**
1. Compare WNS/TNS before vs after
2. Verify all primary criteria: WNS >= 0 ps, TNS = 0 ps
3. Check secondary criteria: margins, clock skew, etc.
4. Issue GO/NO-GO/CONDITIONAL decision

**Output:** Signoff validation report with clear GO/NO-GO/CONDITIONAL decision.

```
IF GO:
→ Timing signoff achieved, pipeline complete

IF NO-GO:
→ Return to Step 2 or 3 with updated data for next iteration
```

## Quality Gate Criteria

| Phase | Gate Criterion | Status |
|-------|----------------|--------|
| Data Ingestion | Data complete | ✅ PASS |
| Violation Analysis | >80% classified | ✅ PASS |
| Strategy Generation | 2+ strategies/violation | ✅ PASS |
| ECO Implementation | No errors | ✅ PASS |
| Quality Validation | WNS >= 0 ps | ⏳ PENDING |

## Key Patterns

1. **Sequential handoffs**: Each agent's output becomes the next agent's input
2. **Quality gates**: Pre-ECO and post-ECO validation ensures progress is measured
3. **Context passing**: Always include previous agent outputs — agents don't share memory
4. **Iteration loop**: If quality gate fails, loop back to analysis with new context
