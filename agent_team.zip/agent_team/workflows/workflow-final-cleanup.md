# Workflow: Final Cleanup

> Pain Point 3: Residual Violation Analysis for Signoff Completion

## Overview

Surgical precision analysis for remaining violations (<50). After multiple ECO iterations, these are the hardest cases requiring targeted analysis.

## Workflow Graph

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│ViolationAnalyzer│ ──▶ │ECOStrategyGen   │ ──▶ │CadenceToolInteg │ ──▶ │SignoffQualityGate│
│  (Deep Dive)    │     │ (Final Cleanup) │     │  (Targeted)     │     │   (Final)        │
└─────────────────┘     └─────────────────┘     └─────────────────┘     └─────────────────┘
                                                                                  │
                                                                                  ▼
                                                                           ┌─────────────────┐
                                                                           │   Orchestrator   │
                                                                           │(Iteration Loop)  │
                                                                           └─────────────────┘
```

## Agents Involved

| Step | Agent | Mode | Role |
|------|-------|------|------|
| 1 | ViolationAnalyzer | DEEP_DIVE | Per-violation surgical analysis |
| 2 | ECOStrategyGenerator | FINAL_CLEANUP | Precision fix recommendations |
| 3 | CadenceToolIntegrator | FINAL_CLEANUP | Execute targeted fixes |
| 4 | SignoffQualityGate | FINAL | Final signoff validation |

## Step 1: Situation Assessment

Before activating agents, assess the situation:

```markdown
Context for Final Cleanup:

Iteration Count: [N] (how many ECO iterations have been run)
Remaining Violations: [N]
- Setup violations: [N]
- Hold violations: [N]
- Worst Slack: [X] ps
- Total Negative Slack: [X] ps

Historical Progression:
| Iteration | Start Violations | End Violations | WNS Start | WNS End |
|-----------|------------------|----------------|-----------|---------|
| 1 | [N] | [N] | [X] ps | [Y] ps |
| 2 | [N] | [N] | [X] ps | [Y] ps |
| ... | ... | ... | ... | ... |

Current Status: [describe what has been tried already]
```

## Step 2: Violation Analyzer (Deep Dive Mode)

**Mode:** DEEP_DIVE (remaining violations cleanup)

**Context:** After [N] ECO iterations, [X] violations remain. Standard analysis has been applied. Now we need surgical precision for these remaining hard cases.

### DEEP DIVE ANALYSIS TASKS:

#### 1. PER-VIOLATION PATH EXTRACTION

For each remaining violation:

```markdown
VIOLATION: [violation_id]
ENDPOINT: [full path endpoint]
CURRENT SLACK: [X] ps

Full Path Analysis:
- Launch FF: [cell name] at ({x, y})
- Capture FF: [cell name] at ({x, y})
- Path depth: [N] logic levels
- Clock skew: [X] ps
- Clock domain: [domain_name]

Cell-by-Cell Breakdown:
| Cell Instance | Cell Type | Delay (ps) | Input Trans (ps) | Output Load (ff) |
|---------------|-----------|------------|------------------|------------------|
| [cell_1] | [type] | [d] | [t] | [c] |

Net Analysis:
| Net Name | Fanout | Total Cap (ff) | Routing Layer | Shielding |
|----------|--------|----------------|---------------|-----------|
| [net_1] | [f] | [c] | M3 | No |
```

#### 2. STAKEHOLDER CORRELATION
Cross-reference remaining violations with:
- Recent design changes (from version history)
- Floorplan modifications
- Placement movements
- Routing changes

Question: Did a specific change cause these remaining issues?

#### 3. MULTI-VIOLATION CORRELATION
Analyze if remaining violations share:
- Common nets (one net affecting multiple endpoints)
- Common clock domains (clock tree issue)
- Common cell types (library issue at specific corner)
- Physical proximity (placement interaction)

**IMPORTANT:** Often 1 fix resolves multiple violations!

#### 4. LIBRARY CORNER ANALYSIS
For each critical cell in remaining paths:
- Compare actual delay vs library model at this corner
- Check if cell is operating near library limits
- Check for inconsistency between RC extraction and library

#### 5. PHYSICAL PROXIMITY ANALYSIS
For cells in critical paths:
- Check neighboring cell density (congestion)
- Check distance to driving/receiving cells
- Check layer assignment for critical nets
- Check via count on critical nets
- Look for spacing issues

### OUTPUT FORMAT:

```markdown
For EACH remaining violation, provide:

## [Violation ID]: [Endpoint]

### ROOT CAUSE: [Specific, actionable root cause]
- Not "LOGIC_DEPTH" but "Cell UCB4 in path has delay 850ps vs library model 720ps at this corner"
- Not "NET_ROUTING" but "Net NET_MEM_23 has 0.85pF capacitance, exceeds 0.7pF threshold for current layer"

### CORRELATED VIOLATIONS: [List if any other violations caused by same issue]

### TAILORED FIX: [Specific strategy for this exact case]
- Exact cell change: [cell_name], [current_type] → [recommended_type]
- OR exact buffer insertion: [net_name], [buffer_type], [location]
- OR exact routing change: [net_name], [layer_change], [shielding_type]

### CONFIDENCE: [X]%

### CADENCE COMMANDS:
Innovus:
> [precise innovus command for this fix]

PrimeTime:
> [verification command after fix]

### FLAGGED FOR MANUAL REVIEW: [YES/NO]
- If YES: Explain why automated fix is risky/low-confidence
- Provide detailed context and recommended approach
- Include worst-case fallback (rollback plan)
```

## Step 3: ECO Strategy Generator (Final Cleanup Mode)

**Context:** These are the final [X] violations blocking signoff. Standard ECO has been applied. We need precision fixes for these specific cases.

### FINAL CLEANUP STRATEGY TASKS:

#### 1. SURGICAL FIX GENERATION

For each remaining violation:

```markdown
VIOLATION: [violation_id]
ROOT_CAUSE: [specific cause from deep dive]

TAILORED_FIX:
- Exact cell change: [cell_name], [current_type] → [recommended_type]
- OR exact buffer insertion location: [net_name], [recommended_buffer_type]
- OR exact routing change: [net_name], [layer_change], [shielding]
- Expected slack improvement: [X] ps
- Risk of regression: [LOW/MEDIUM/HIGH]

CADENCE TOOL COMMANDS:
Innovus:
> [precise innovus command for this fix]

PrimeTime:
> [verification command after fix]
```

#### 2. BATCH OPTIMIZATION
If multiple violations share a cause:
- Can one cell change fix multiple violations?
- What's the optimal order of fixes to avoid regression?
- Group fixes into minimal ECO operations

**Example Batch Groups:**
- Batch A: Cell sizing (5 cells) — safe to do together
- Batch B: Buffer insertions (3 nets) — independent
- Batch C: Routing changes (2 nets) — risk of interaction

#### 3. MANUAL INTERVENTION FLAGGING

For violations where automated fix is risky/low-confidence:

```markdown
## MANUAL ECO REQUIRED: [Violation ID]

Context:
- Why automated fix is risky: [explanation]
- Recommended approach: [detailed steps]
- Expert level required: [Junior/Senior/Expert]
- Rollback plan: [commands to rollback if needed]
```

#### 4. SIGN-OFF RISK ASSESSMENT

For each remaining violation after recommended fixes:
- Probability of fix success: [HIGH/MEDIUM/LOW]
- If fix succeeds, will violation truly be resolved?
- Any corner cases that might cause re-emergence?

```markdown
| Violation | Fix Success Prob | True Resolution | Corner Risk |
|-----------|-----------------|-----------------|--------------|
| V001 | 92% | Yes | LOW |
| V002 | 88% | Yes | LOW |
| V003 | 65% | Maybe | MEDIUM |
```

**Output:**
- Final cleanup strategy document
- Priority-ordered fix list
- Batch recommendations
- Manual intervention checklist
- Signoff readiness assessment

## Step 4: Cadence Tool Integrator (Final Cleanup)

**Mode:** FINAL_CLEANUP

**Implementation Priority:**

**PHASE 1: Safe Automated Fixes (High Confidence)**
1. Batch A: [list fixes]
2. Verify after each batch

**PHASE 2: Medium Confidence Fixes**
1. [list fixes]
2. Verify after each fix

**PHASE 3: Manual ECO (if flagged)**
1. [list violations requiring manual intervention]
2. Provide detailed context for manual ECO

**For each automated fix:**
- Execute precise Cadence command
- Verify slack improvement
- Check for regressions
- Save checkpoint

**For manual ECO items:**
- Provide complete documentation
- Include all context
- Specify verification criteria

**Output:** Implementation report with results for each fix.

## Step 5: Signoff Quality Gate (Final)

**Context:** Final validation after all remaining violation fixes

### FINAL VALIDATION TASKS:

#### 1. PRIMARY CRITERIA
- WNS (Setup) >= 0 ps: [ACTUAL] ps → PASS/FAIL
- WNS (Hold) >= 0 ps: [ACTUAL] ps → PASS/FAIL
- TNS (Setup) = 0 ps: [ACTUAL] ps → PASS/FAIL
- TNS (Hold) = 0 ps: [ACTUAL] ps → PASS/FAIL

#### 2. MARGIN ASSESSMENT
- Setup margin > 10 ps: [ACTUAL] ps → PASS/FAIL
- Hold margin > 5 ps: [ACTUAL] ps → PASS/FAIL
- Clock skew within limits: [ACTUAL] ps → PASS/FAIL

#### 3. QUALITY ASSESSMENT
- Overall robustness: [HIGH/MEDIUM/LOW]
- Risk factors identified: [list]
- Remaining concerns: [list]

### FINAL DECISION:

```
[ ] ✅ GO — All criteria met with adequate margin. Design ready for signoff.

[ ] ❌ NO-GO — Criteria not met. Return to analysis.

[ ] ⚠️ CONDITIONAL — Criteria met with conditions.
  Conditions:
  1. [condition 1]
  2. [condition 2]
```

## Key Patterns

1. **Surgical precision**: Each violation gets cell-by-cell, net-by-net analysis
2. **Multi-violation correlation**: Often one fix resolves multiple violations
3. **Batch optimization**: Group compatible fixes for efficiency
4. **Manual intervention flagging**: Know when to escalate to experts

## Tips

- Deep dive mode is for <50 violations — if you have more, use standard analysis first
- Look for correlated issues — fixing one net may fix multiple violations
- Library corner issues are often hidden — compare actual vs model delay
- Physical proximity issues (congestion, spacing) are easy to miss but common in final cleanup
- If confidence is <70%, consider manual ECO — don't force automated fixes that might make things worse
- Always have rollback plans for final cleanup — you don't want to undo good work
